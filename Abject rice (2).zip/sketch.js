var r,e,h;
		function setup() { 
  createCanvas(400, 400);
	frameRate(1500);
		background(220)
r = random(255);
	e = random(255);
	h = random(255)
	}
		
function draw() { 
	strokeWeight(2)
	stroke(r,e,h)
	fill(r,e,h, 10)
	rect(mouseX,mouseY,50,100)
	ellipse(350,400,300,mouseY)
	ellipse(50,0,300,mouseY)
	ellipse(50,400,mouseX,400)
	ellipse(350,50,mouseX,200)
}

function mousePressed(){
r = random(255);
e = random(255);
h= random(255)
}

function mouseWheel() {
	background(r,e,h,50);
}

